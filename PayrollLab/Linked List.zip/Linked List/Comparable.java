// comparable.java interface

public interface Comparable {
    public int compareTo(Object o);
}

