
public interface ObjectBinaryTreeInterface {
	public int compareTo(Object o);
}

