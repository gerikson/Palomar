/**
 * Comparable interface
 * @author Galina Erikson (Palomar ID 009280295)
 * @version 1.1 - April 9th, 2014
 *
 */
public interface Comparable {
    public int compareTo(Object o);
}

